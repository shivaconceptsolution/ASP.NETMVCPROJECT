﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcBasic.Models;
namespace MvcBasic.Controllers
{
    public class AppointmentController : Controller
    {

        //
        // GET: /Appointment/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
           
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection obj)
        {

           
            Appointment obj1 = new Appointment();
            obj1.Email = obj["txtemail"];
            obj1.Patientname = obj["txtfname"];
            obj1.Mobileno = obj["txtmobile"];
            obj1.Description = obj["txtdesc"];
            obj1.Appointmentdate = DateTime.Now.ToShortDateString();
            db.Appointments.Add(obj1);
            db.SaveChanges();
            ViewBag.data = "Data Inserted SuccessFully";
            return View();
        }
        public ActionResult DoctorLogin()
        {
            return View();
        }
        public ActionResult PatientLogin()
        {
            return View();
        }
    }
}
